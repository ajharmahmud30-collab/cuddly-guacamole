import os, io, csv, re, datetime, hashlib, hmac, secrets
from pathlib import Path
from collections import defaultdict
from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, Request
from fastapi.responses import FileResponse, StreamingResponse, JSONResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from sqlalchemy import create_engine, text
from openpyxl import load_workbook

ROOT=Path(__file__).resolve().parents[1]
url=os.getenv('DATABASE_URL','sqlite:///'+str(ROOT/'local.sqlite3'))
if url.startswith('postgres://'): url='postgresql+psycopg://'+url[len('postgres://'):]
elif url.startswith('postgresql://'): url='postgresql+psycopg://'+url[len('postgresql://'):]
engine=create_engine(url,pool_pre_ping=True)
with engine.begin() as c:
 c.execute(text('CREATE TABLE IF NOT EXISTS riders (id TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT \'\', mobile TEXT DEFAULT \'\', iqama_expiry TEXT DEFAULT \'\', license_expiry TEXT DEFAULT \'\', vehicle TEXT DEFAULT \'\', status TEXT DEFAULT \'active\')'))
 c.execute(text('CREATE TABLE IF NOT EXISTS orders (source_hash TEXT NOT NULL, sheet TEXT NOT NULL, row_number INTEGER NOT NULL, rider_id TEXT NOT NULL, day TEXT NOT NULL, orders DOUBLE PRECISION NOT NULL, hours DOUBLE PRECISION, km DOUBLE PRECISION, wallet DOUBLE PRECISION, cancelled DOUBLE PRECISION, PRIMARY KEY(source_hash,sheet,row_number))'))

app=FastAPI(title='NAJD Rider Management',docs_url=None,redoc_url=None,openapi_url=None)
security=HTTPBasic(auto_error=False)
ADMIN_USER=os.getenv('ADMIN_USERNAME','')
ADMIN_PASSWORD=os.getenv('ADMIN_PASSWORD','')
if os.getenv('RENDER') and (not ADMIN_USER or len(ADMIN_PASSWORD)<16 or not os.getenv('DATABASE_URL')):
 raise RuntimeError('Set ADMIN_USERNAME, ADMIN_PASSWORD (16+ chars) and DATABASE_URL on Render before deploying')

def auth(credentials:HTTPBasicCredentials=Depends(security)):
 if not ADMIN_USER or not ADMIN_PASSWORD: raise HTTPException(503,'Configure ADMIN_USERNAME and ADMIN_PASSWORD')
 if not credentials or not (secrets.compare_digest(credentials.username,ADMIN_USER) and secrets.compare_digest(credentials.password,ADMIN_PASSWORD)):
  raise HTTPException(401,'Authentication required',headers={'WWW-Authenticate':'Basic realm="NAJD Rider Dashboard"'})
 return credentials.username

@app.middleware('http')
async def security_headers(request:Request,call_next):
 if request.method in ('POST','PUT','PATCH','DELETE'):
  origin=request.headers.get('origin')
  if origin and origin.rstrip('/')!=str(request.base_url).rstrip('/'):
   return JSONResponse({'detail':'Origin rejected'},status_code=403)
 response=await call_next(request)
 response.headers['X-Content-Type-Options']='nosniff'
 response.headers['X-Frame-Options']='DENY'
 response.headers['Referrer-Policy']='no-referrer'
 response.headers['Cache-Control']='no-store'
 response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'"
 return response

@app.get('/health')
def health():return {'status':'ok'}
@app.get('/')
def home(_=Depends(auth)):return FileResponse(ROOT/'web'/'index.html')
@app.get('/api/riders')
def riders(_=Depends(auth)):
 with engine.connect() as c:return [dict(x) for x in c.execute(text('SELECT * FROM riders ORDER BY name,id')).mappings()]
@app.post('/api/riders')
def upsert_rider(payload:dict,_=Depends(auth)):
 rid=str(payload.get('id','')).strip()
 if not rid or len(rid)>80:raise HTTPException(400,'Valid Rider ID required')
 fields=['name','mobile','iqama_expiry','license_expiry','vehicle','status']
 data={k:str(payload.get(k,'')).strip()[:255] for k in fields};data['id']=rid
 if data['status'] not in ('active','inactive'):raise HTTPException(400,'Invalid status')
 with engine.begin() as c:
  c.execute(text('INSERT INTO riders(id,name,mobile,iqama_expiry,license_expiry,vehicle,status) VALUES(:id,:name,:mobile,:iqama_expiry,:license_expiry,:vehicle,:status) ON CONFLICT(id) DO UPDATE SET name=excluded.name,mobile=excluded.mobile,iqama_expiry=excluded.iqama_expiry,license_expiry=excluded.license_expiry,vehicle=excluded.vehicle,status=excluded.status'),data)
 return {'saved':rid}

def norm(v):return re.sub(r'[^a-z0-9\u0600-\u06ff]','',str(v or '').lower())
def get(row,*keys):
 d={norm(k):v for k,v in row.items()}
 for k in keys:
  if norm(k) in d:return d[norm(k)]
def number(v):
 try:return float(str(v).replace(',','')) if v is not None and v!='' else None
 except (TypeError,ValueError):return None
def hours(v):
 if isinstance(v,datetime.time):return v.hour+v.minute/60
 if v is None or v=='':return None
 s=str(v).strip()
 try:
  if ':' in s:
   a,b=s.split(':')[:2];return int(a)+int(b)/60 if 0<=int(b)<60 else None
  a,*b=s.split('.');minutes=int((b[0] if b else '0').ljust(2,'0')[:2]);return int(a)+minutes/60 if 0<=minutes<60 else None
 except ValueError:return None
def day(v):
 if isinstance(v,datetime.datetime):return v.date().isoformat()
 if isinstance(v,datetime.date):return v.isoformat()
 if isinstance(v,(float,int)):
  from openpyxl.utils.datetime import from_excel
  try:return from_excel(v).date().isoformat()
  except Exception:return ''
 for f in ('%Y-%m-%d','%d/%m/%Y','%m/%d/%Y','%d-%m-%Y'):
  try:return datetime.datetime.strptime(str(v)[:10],f).date().isoformat()
  except ValueError:pass
 return ''
def table_rows(ws):
 it=ws.iter_rows(values_only=True);headers=None
 for row in it:
  candidate=[str(v or '').strip() for v in row]
  if any(norm(x) in ('id','date','idnormalizedauto','idnormalized','riderid') for x in candidate):headers=candidate;break
 if not headers:return
 for row in it:
  if any(v is not None for v in row):yield dict(zip(headers,row))

@app.post('/api/import')
async def import_files(files:list[UploadFile]=File(...),_=Depends(auth)):
 imported=skipped=0;errors=[]
 for f in files:
  name=f.filename or 'upload'
  if not name.lower().endswith(('.xlsx','.csv')):errors.append(f'{name}: unsupported format');continue
  blob=await f.read(10*1024*1024+1)
  if len(blob)>10*1024*1024:errors.append(f'{name}: exceeds 10MB limit');continue
  digest=hashlib.sha256(blob).hexdigest()
  try:
   names={};corrections={}
   if name.lower().endswith('.csv'):
    rows=list(csv.DictReader(io.StringIO(blob.decode('utf-8-sig'))));sheets=[('CSV',rows)]
   else:
    wb=load_workbook(io.BytesIO(blob),read_only=True,data_only=True)
    for sn in wb.sheetnames:
     if 'master' in sn.lower():
      for r in table_rows(wb[sn]) or []:
       k=get(r,'ID (normalized)','ID');v=get(r,'Name')
       if k and v:names[str(k).strip()]=str(v)
     if 'correction' in sn.lower():
      for r in table_rows(wb[sn]) or []:
       k=get(r,'ID (as it appeared)');v=get(r,'Official ID (normalized)')
       if k and v:corrections[str(k).strip()]=str(v).strip()
    chosen=[sn for sn in wb.sheetnames if norm(sn)=='rawdata'] or [sn for sn in wb.sheetnames if not any(x in sn.lower() for x in ('summary','master','correction'))]
    sheets=[(sn,list(table_rows(wb[sn]) or [])) for sn in chosen]
   with engine.begin() as c:
    for sn,rows in sheets:
     for i,r in enumerate(rows,1):
      rid=get(r,'ID (normalized, auto)','ID (normalized)','Rider ID','ID');qty=number(get(r,'Orders','Total Orders','Order Count'))
      if not rid or qty is None or qty<0:skipped+=1;continue
      rid=str(rid).strip();rid=corrections.get(rid,rid)
      d=day(get(r,'Date','Day'))
      if not d:skipped+=1;continue
      nm=str(get(r,'Name (normalized, auto)','Name (optional)','Rider Name','Name') or names.get(rid,'')).strip()
      c.execute(text('INSERT INTO riders(id,name) VALUES(:id,:name) ON CONFLICT(id) DO UPDATE SET name=excluded.name WHERE riders.name=\'\''),{'id':rid,'name':nm})
      args={'source_hash':digest,'sheet':sn,'row_number':i,'rider_id':rid,'day':d,'orders':qty,'hours':hours(get(r,'Working Hours','Total Working Hours')),'km':number(get(r,'KM','Total KM')),'wallet':number(get(r,'Wallet','Wallet Balance (Total)')),'cancelled':number(get(r,'Cancelled'))}
      result=c.execute(text('INSERT INTO orders(source_hash,sheet,row_number,rider_id,day,orders,hours,km,wallet,cancelled) VALUES(:source_hash,:sheet,:row_number,:rider_id,:day,:orders,:hours,:km,:wallet,:cancelled) ON CONFLICT(source_hash,sheet,row_number) DO NOTHING'),args)
      imported+=result.rowcount;skipped+=1-result.rowcount
  except Exception as e:errors.append(f'{name}: could not import ({type(e).__name__})')
 return {'imported':imported,'skipped':skipped,'errors':errors}

@app.get('/api/dashboard')
def dashboard(month:str='',q:str='',target:int=450,_=Depends(auth)):
 if not 1<=target<=100000:raise HTTPException(400,'Invalid target')
 if month and not re.fullmatch(r'\d{4}-\d{2}',month):raise HTTPException(400,'Invalid month')
 with engine.connect() as c:
  rows=[dict(r) for r in c.execute(text('SELECT o.*,r.name,r.vehicle FROM orders o LEFT JOIN riders r ON r.id=o.rider_id WHERE (:month=\'\' OR substr(o.day,1,7)=:month) AND (:q=\'\' OR o.rider_id LIKE :pattern OR r.name LIKE :pattern) ORDER BY o.day'),{'month':month,'q':q,'pattern':'%'+q+'%'}).mappings()]
  count=c.execute(text('SELECT COUNT(*) FROM riders')).scalar_one()
 agg={};trend=defaultdict(float)
 for r in rows:
  a=agg.setdefault(r['rider_id'],{'id':r['rider_id'],'name':r['name'] or 'Unknown','vehicle':r['vehicle'],'orders':0,'days':set(),'hours':0,'km':0,'wallet':0,'cancelled':0,'present':set()})
  a['orders']+=r['orders'];a['days'].add(r['day'])
  for k in ('hours','km','wallet','cancelled'):
   if r[k] is not None:a[k]+=r[k];a['present'].add(k)
  trend[r['day']]+=r['orders']
 for a in agg.values():
  a['days']=len(a['days']);a['average']=round(a['orders']/a['days'],2) if a['days'] else 0;a['target_pct']=round(a['orders']/target*100,1)
  for k in ('hours','km','wallet'):
   if k not in a['present']:a[k]=None
  del a['present']
 return {'summary':{'riders':len(agg),'registered_riders':count,'orders':sum(r['orders'] for r in rows),'hours':round(sum(r['hours'] or 0 for r in rows),2),'km':round(sum(r['km'] or 0 for r in rows),2),'target_achievers':sum(a['orders']>=target for a in agg.values())},'riders':sorted(agg.values(),key=lambda x:-x['orders']),'trend':[{'date':k,'orders':v} for k,v in sorted(trend.items())]}
@app.get('/api/export.csv')
def export(month:str='',_=Depends(auth)):
 with engine.connect() as c:rows=[dict(r) for r in c.execute(text('SELECT day,rider_id,orders,hours,km,wallet FROM orders WHERE (:month=\'\' OR substr(day,1,7)=:month) ORDER BY day'),{'month':month}).mappings()]
 out=io.StringIO();w=csv.DictWriter(out,fieldnames=['day','rider_id','orders','hours','km','wallet']);w.writeheader();w.writerows(rows)
 return StreamingResponse(iter(['\ufeff'+out.getvalue()]),media_type='text/csv',headers={'Content-Disposition':'attachment; filename="NAJD_orders.csv"'})
