# NAJD LOGISTIC SERVICE — Online Rider Dashboard (Free Hosting Starter)

This is a **single-admin pilot** web application, not a production-grade payroll or identity-management system. It has a password-protected FastAPI dashboard, Excel/CSV import, riders, orders, charts, CSV export, and PostgreSQL support. It does **not** include a native desktop executable, multiple user roles, automated backups, password reset, audit logs, or verified Saudi PDPL compliance.

## Recommended free hosting: Render Web Service + Neon PostgreSQL

**Do not use the local SQLite database on Render.** Render Free web services have an ephemeral filesystem. Render Free Postgres expires after 30 days, so a separately hosted Neon database is preferable for an ongoing test. Free services may sleep, have usage limits, and are not appropriate for critical production workloads.

### 1. Create a Neon database

1. Visit https://console.neon.tech and create an account and a free PostgreSQL project.
2. Choose a region appropriate for your needs. Open the **Connect** dialog and copy the PostgreSQL connection string (with `sslmode=require`).
3. Keep it secret. **Never** paste it into GitHub, public chats, or files inside this project.
4. Neon free-tier quotas can change; review its current plan and backup/restore terms.

### 2. Push project to a private GitHub repository

1. Extract this ZIP, and upload **the files inside the `NAJD_Online_Deployment` folder** to the root of a **private** GitHub repository.
2. Do not upload `.env`, `local.sqlite3`, or rider spreadsheets. `.gitignore` is included.
3. Do not commit secrets. You will enter them in Render environment settings.

### 3. Deploy to Render

1. Go to https://dashboard.render.com, log in, choose **New > Web Service**, and connect your GitHub repository.
2. Runtime: **Python**; instance type: **Free**.
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn backend.main:app --host 0.0.0.0 --port $PORT --proxy-headers --forwarded-allow-ips='*'`
5. Add environment variables:
   - `DATABASE_URL`: Neon PostgreSQL connection URL (secret)
   - `ADMIN_USERNAME`: your chosen admin username
   - `ADMIN_PASSWORD`: a **unique, randomly generated password of at least 16 characters**
   - `PYTHON_VERSION`: `3.12.8`
6. Click **Deploy Web Service**. Wait for deploy success and open the assigned `https://...onrender.com` URL. Browser will request the admin credentials.
7. Use `/health` to check the app status. Do not interpret `/health` as proof the database is healthy.

Alternative: **New > Blueprint** can use `render.yaml`; you still must set the three secret environment variables. Avoid accidentally creating a paid service.

### 4. Test safely

- Create a fake rider and upload a test CSV with columns `ID,Date,Orders,Working Hours,KM`.
- Confirm the dashboard and CSV export.
- Re-upload the **same exact file**; imported rows should be skipped.
- Back up your data regularly using authenticated CSV export. CSV export only covers orders, not full rider records or database backups.
- Before uploading real rider names, phone numbers or Iqama-related information, verify company authorization, privacy requirements, provider location, access controls, retention, and backup procedures. Use synthetic data for initial testing.

### 5. Local test (optional)

Python 3.12+ recommended:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
# Set ADMIN_USERNAME and ADMIN_PASSWORD in your shell, and optionally DATABASE_URL.
uvicorn backend.main:app --reload
```

Open http://127.0.0.1:8000 and enter the credentials.

### Security notes and known limitations

- HTTP Basic Authentication must only be used over HTTPS when deployed. Browser may remember credentials until closed; use a private device and sign out by closing the browser. Rotate passwords through Render secrets if compromised.
- Single shared admin account only. No per-supervisor permissions, login throttling, MFA, audit trail, automated backups, or advanced session controls.
- Same-file deduplication uses SHA-256 of file bytes plus sheet/row. Uploading changed files with overlapping records can still duplicate orders; do not upload modified copies of existing daily reports without reconciliation.
- Imports have a 10 MB per-file cap. A malformed workbook may consume more memory after decompression; only upload trusted files.
- Salary and wallet are **not** equivalent. Salary/bonus calculations require confirmed company rules.
- Free Render services sleep after 15 minutes of inactivity; cold starts can take about a minute. Render Free web services have ephemeral local storage.
- A production rollout requires external backup and restore tests, stronger authentication, audit logs, database migrations, privacy assessment, and security review.
